Tracker Kit 1.0
A self-contained bike build tracker page. One HTML file per theme, no server, no accounts, no tracking, no external links.

What is inside
  hud/index.html, stealth/index.html, chrome/index.html, classic/index.html  (four themes, example build filled in)
  build.json   your build: stages, parts, costs. Edit this.
  gen.py       regenerates a page from build.json (Python 3, no installs)

How to open
  Double click any index.html. It opens in your browser. Works offline.

Make it yours
  1. Edit build.json with your bike, stages (done, active, todo) and parts.
  2. Run: python3 gen.py build.json --theme hud --out mybuild
  3. Open mybuild/index.html. Host it anywhere or keep it local.
  Themes: hud, stealth, chrome, classic.

No third party IP
  All layout, styles and code are original. No logos, brand marks, fonts or images from other companies. Bike names in the example are plain text.
