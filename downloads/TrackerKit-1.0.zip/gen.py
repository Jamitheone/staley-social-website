#!/usr/bin/env python3
"""Tracker Kit: render a self-contained static bike build tracker.
Usage: gen.py <build.json> --theme hud|stealth|chrome|classic --out DIR
       gen.py --check
Progress % = (done + 0.5*active) / stages, rounded. Layout from seda/trackers/cb650."""
import argparse, html, json, math, re, sys, tempfile, zipfile
from html.parser import HTMLParser
from pathlib import Path

HERE = Path(__file__).parent
THEMES = ["hud", "stealth", "chrome", "classic"]
WEIGHT = {"done": 1, "active": 0.5, "todo": 0}
BASE = """*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.7 var(--font)}
.wrap{max-width:820px;margin:0 auto;padding:28px 18px 80px}
header{border-bottom:1px solid var(--line);padding-bottom:18px;margin-bottom:24px;display:flex;gap:20px;align-items:center;justify-content:space-between;flex-wrap:wrap}
.eyebrow{color:var(--accent);letter-spacing:.08em;font-size:11px;text-transform:uppercase}
h1{font-size:28px;margin:8px 0 4px}.sub{color:var(--dim);font-size:12px}
.ring{width:110px;height:110px;position:relative}.ring svg{transform:rotate(-90deg)}
.ring .pct{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:20px 0}
.stat{background:var(--panel);border:1px solid var(--line);border-radius:var(--r);padding:12px 14px}
.stat b{display:block;font-size:19px;margin-top:3px}
.stat span{color:var(--dim);font-size:11px;letter-spacing:.05em;text-transform:uppercase}
h2{font-size:12px;letter-spacing:.07em;text-transform:uppercase;color:var(--accent);margin:32px 0 12px;padding-bottom:8px;border-bottom:1px solid var(--line)}
ul{list-style:none;margin:0;padding:0}
li.st{background:var(--panel);border:1px solid var(--line);border-left:3px solid var(--line);border-radius:0 var(--r) var(--r) 0;padding:11px 14px;margin-bottom:8px}
li.st.done{border-left-color:var(--good)}li.st.active{border-left-color:var(--accent)}
li.st .when{color:var(--dim);font-size:11px;letter-spacing:.04em;text-transform:uppercase}
.tag{float:right;font-size:11px;text-transform:uppercase;color:var(--dim)}
.card{background:var(--panel);border:1px solid var(--line);border-radius:var(--r);padding:16px}
table{width:100%;border-collapse:collapse;font-size:14px}
td,th{padding:8px 0;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
td.n,th.n{text-align:right}tr:last-child td{border-bottom:0}
.photos{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}
.ph{aspect-ratio:4/3;background:var(--panel2);border:1px dashed var(--line);border-radius:var(--r);display:flex;align-items:flex-end;justify-content:center;overflow:hidden;color:var(--dim);font-size:12px}
.ph img{width:100%;height:100%;object-fit:cover}.ph span{padding:8px}
footer{margin-top:44px;padding-top:16px;border-top:1px solid var(--line);color:var(--dim);font-size:11px}
"""

def pct(stages):
    if not stages: return 0
    return round(100 * sum(WEIGHT[s["status"]] for s in stages) / len(stages))

def e(x): return html.escape(str(x))

def render(b, theme):
    for s in b["stages"]:
        if s["status"] not in WEIGHT: raise ValueError("bad status %r" % s["status"])
    p = pct(b["stages"])
    r = 46; c = 2 * math.pi * r
    css = BASE + (HERE / "themes" / (theme + ".css")).read_text()
    cost = sum(x["cost"] for x in b["parts"])
    hrs = sum(x["hrs"] for x in b["hours"])
    stages = "".join(
        '<li class="st %s"><span class="tag">%s</span><div class="when">%s</div><div>%s</div><div class="sub">%s</div></li>'
        % (s["status"], e(s["status"]), e(s.get("date") or "not started"), e(s["name"]), e(s.get("note", "")))
        for s in b["stages"])
    parts = "".join('<tr><td>%s</td><td>%s</td><td class="n">$%.2f</td></tr>' % (e(x["name"]), e(x["source"]), x["cost"]) for x in b["parts"])
    hours = "".join('<tr><td>%s</td><td>%s</td><td class="n">%g</td></tr>' % (e(x["date"]), e(x["what"]), x["hrs"]) for x in b["hours"])
    photos = "".join(
        '<div class="ph">%s<span>%s</span></div>' % ('<img src="%s" alt="%s">' % (e(x["src"]), e(x["caption"])) if x.get("src") else "", e(x["caption"]))
        for x in b["photos"])
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex"><title>{e(b["bike"])} Build Tracker</title>
<style>{css}</style></head><body><div class="wrap">
<header><div><div class="eyebrow">Build tracker</div><h1>{e(b["bike"])}</h1><div class="sub">Owner: {e(b["owner"])}</div></div>
<div class="ring"><svg width="110" height="110" viewBox="0 0 110 110"><circle cx="55" cy="55" r="{r}" fill="none" stroke="var(--line)" stroke-width="8"/><circle cx="55" cy="55" r="{r}" fill="none" stroke="var(--accent)" stroke-width="8" stroke-linecap="round" stroke-dasharray="{c:.2f}" stroke-dashoffset="{c * (1 - p / 100):.2f}"/></svg><div class="pct" id="pct">{p}%</div></div></header>
<div class="grid"><div class="stat"><span>Overall</span><b>{p}%</b></div><div class="stat"><span>Parts spend</span><b>${cost:,.2f}</b></div><div class="stat"><span>Hours</span><b>{hrs:g}</b></div><div class="stat"><span>Shop rate</span><b>${b.get("rate", 0):g}/hr</b></div></div>
<h2>Timeline</h2><ul>{stages}</ul>
<h2>Parts</h2><div class="card"><table><tr><th>Part</th><th>Source</th><th class="n">Cost</th></tr>{parts}</table></div>
<h2>Hours</h2><div class="card"><table><tr><th>Date</th><th>Work</th><th class="n">Hrs</th></tr>{hours}</table></div>
<h2>Photos</h2><div class="photos">{photos}</div>
<footer>Tracker Kit, theme {e(theme)}</footer></div></body></html>"""

class P(HTMLParser):
    def __init__(s): super().__init__(); s.stack = []; s.bad = []
    VOID = {"meta", "img", "circle", "br", "input", "link"}
    def handle_starttag(s, t, a):
        if t not in s.VOID: s.stack.append(t)
    def handle_startendtag(s, t, a): pass
    def handle_endtag(s, t):
        if not s.stack or s.stack.pop() != t: s.bad.append(t)

def check():
    b = json.loads((HERE / "fixture.json").read_text())
    want = round(100 * (2 + 0.5) / 5)
    assert pct(b["stages"]) == want == 50, "pct"
    with tempfile.TemporaryDirectory() as d:
        for t in THEMES:
            out = Path(d) / t
            main_render(b, t, out)
            h = (out / "index.html").read_text()
            p = P(); p.feed(h)
            assert not p.bad and not p.stack, (t, "html", p.bad, p.stack)
            assert not re.search(r'(https?:)?//[\w.-]+\.\w', h), (t, "external url")
            assert "—" not in h and "–" not in h, (t, "dash")
            assert 'id="pct">%d%%' % want in h, (t, "pct text")
    z = HERE / "dist" / "TrackerKit-1.0.zip"
    with zipfile.ZipFile(z) as zf:
        assert zf.testzip() is None, "zip corrupt"
        names = zf.namelist()
        assert "README.txt" in names, "zip readme"
        for t in THEMES: assert t + "/index.html" in names, (t, "not in zip")
        assert len({n.split("/")[0] for n in names if n.endswith("/index.html")}) == 4, "theme count"
    print("check ok: %d themes, zip lists %d" % (len(THEMES), len(THEMES)))

def pack():
    b = json.loads((HERE / "fixture.json").read_text())
    (HERE / "dist").mkdir(exist_ok=True)
    with zipfile.ZipFile(HERE / "dist" / "TrackerKit-1.0.zip", "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(HERE / "README.txt", "README.txt")
        zf.write(HERE / "fixture.json", "build.json")
        zf.write(HERE / "gen.py", "gen.py")
        for t in THEMES:
            zf.writestr(t + "/index.html", render(b, t))
            zf.write(HERE / "themes" / (t + ".css"), "themes/" + t + ".css")

def main_render(b, theme, out):
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    (out / "index.html").write_text(render(b, theme))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("build", nargs="?"); ap.add_argument("--theme", default="hud", choices=THEMES)
    ap.add_argument("--out"); ap.add_argument("--check", action="store_true"); ap.add_argument("--pack", action="store_true")
    a = ap.parse_args()
    if a.pack: pack(); print("packed"); sys.exit(0)
    if a.check: check(); sys.exit(0)
    if not (a.build and a.out): ap.error("need <build.json> and --out")
    main_render(json.loads(Path(a.build).read_text()), a.theme, a.out)
    print(Path(a.out) / "index.html")
